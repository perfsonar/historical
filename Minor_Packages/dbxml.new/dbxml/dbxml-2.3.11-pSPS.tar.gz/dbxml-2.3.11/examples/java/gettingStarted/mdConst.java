//
// See the file LICENSE for redistribution information.
//
// Copyright (c) 2004,2006 Oracle.  All rights reserved.
//
// $Id: mdConst.java,v 1.6 2006/10/30 17:45:47 bostic Exp $
//

package dbxml.gettingStarted;

//Simple class used to encapsulate some constants used throughout
// these examples.
public class mdConst
{
   public static String uri = new String("http://dbxmlExamples/timestamp");
   public static String prefix = new String("time");
   public static String name = new String("timeStamp");

}

