define("dojox/collections", ["./collections/_base"], function(collections){
	/*=====
	 return {
	 // summary:
	 //		Deprecated.  Should require dojox/collections modules directly rather than trying to access them through
	 //		this module.
	 };
	 =====*/	return collections;
});
