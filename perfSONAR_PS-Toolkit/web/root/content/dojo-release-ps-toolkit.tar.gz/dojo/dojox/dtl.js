define("dojox/dtl", ["./dtl/_base"], function(dxdtl){
	/*=====
	 return {
	 // summary:
	 //		Deprecated.  Should require dojox/dtl modules directly rather than trying to access them through
	 //		this module.
	 };
	 =====*/
	return dxdtl;
});