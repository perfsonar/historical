define("dojox/mvc", ["./mvc/_base"], function(dxmvc){
	// module:
	//		dojox/mvc

	/*=====
	 return {
	 // summary:
	 //		Deprecated.  Should require dojox/mvc modules directly rather than trying to access them through
	 //		this module.
	 };
	 =====*/

	return dxmvc;
});
