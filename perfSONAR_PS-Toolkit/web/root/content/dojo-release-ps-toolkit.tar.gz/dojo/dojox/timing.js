define("dojox/timing", ["./timing/_base"], function(timing){
	/*=====
	 return {
	 // summary:
	 //		Deprecated.  Should require dojox/timing modules directly rather than trying to access them through
	 //		this module.
	 };
	 =====*/
	return timing;
});
