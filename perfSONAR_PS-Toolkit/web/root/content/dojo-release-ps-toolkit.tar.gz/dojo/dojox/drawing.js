define("dojox/drawing", ['./drawing/_base'],function(){
	/*=====
	 return {
	 // summary:
	 //		Deprecated.  Should require dojox/drawing modules directly rather than trying to access them through
	 //		this module.
	 };
	 =====*/
});
