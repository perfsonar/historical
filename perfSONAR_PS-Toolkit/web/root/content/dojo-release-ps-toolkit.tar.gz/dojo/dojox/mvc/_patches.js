define("dojox/mvc/_patches", [
	"./_atBindingExtension",
	"./_DataBindingExtension",
	"./_TextBoxExtensions"
], function(){});
