define(
"dojox/widget/nls/nb/Wizard", ({
next: "Neste",
previous: "Forrige",
done: "Ferdig"
})
);
