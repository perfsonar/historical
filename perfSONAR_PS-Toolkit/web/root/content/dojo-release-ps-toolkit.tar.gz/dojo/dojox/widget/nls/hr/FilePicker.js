define(
"dojox/widget/nls/hr/FilePicker", ({
	name: "Ime",
	path: "Staza",
	size: "Veličina (u bajtovima)"
})
);
