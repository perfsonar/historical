// wrapped by build app
define("dojox/widget/gauge/_Gauge", ["dijit","dojo","dojox","dojo/require!dojox/gauges/_Gauge"], function(dijit,dojo,dojox){
dojo.provide("dojox.widget.gauge._Gauge");
dojo.require("dojox.gauges._Gauge");

dojox.widget.gauge._Gauge = dojox.gauges._Gauge;
dojox.widget.gauge.Range = dojox.gauges.Range;
dojox.widget.gauge._indicator = dojox.gauges._indicator;

});
