define(
"dojox/widget/nls/cs/Wizard", ({
next: "Další",
previous: "Předchozí",
done: "Hotovo"
})
);
