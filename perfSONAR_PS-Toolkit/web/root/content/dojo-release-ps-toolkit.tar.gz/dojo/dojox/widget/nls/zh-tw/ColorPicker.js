define(
"dojox/widget/nls/zh-tw/ColorPicker", ({
redLabel: "r",
greenLabel: "g",
blueLabel: "b",
hueLabel: "h",
saturationLabel: "s",
valueLabel: "v", /* aka intensity or brightness */
degLabel: "\u00B0",
hexLabel: "十六進位",
huePickerTitle: "色調選取元",
saturationPickerTitle: "飽和度選取元"
})
);
