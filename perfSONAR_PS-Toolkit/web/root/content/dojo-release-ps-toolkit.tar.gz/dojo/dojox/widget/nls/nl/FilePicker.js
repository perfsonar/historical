define(
"dojox/widget/nls/nl/FilePicker", ({
	name: "Naam",
	path: "Pad",
	size: "Grootte (in bytes)"
})
);
