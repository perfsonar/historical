define(
"dojox/widget/nls/el/ColorPicker", ({
redLabel: "κ",
greenLabel: "π",
blueLabel: "μ",
hueLabel: "α",
saturationLabel: "κ",
valueLabel: "τ", /* aka intensity or brightness */
degLabel: "\u00B0",
hexLabel: "16-αδικό",
huePickerTitle: "Επιλογή απόχρωσης",
saturationPickerTitle: "Επιλογή κορεσμού"
})
);
