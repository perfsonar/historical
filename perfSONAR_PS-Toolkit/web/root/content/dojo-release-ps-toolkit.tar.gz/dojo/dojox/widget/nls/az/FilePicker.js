define(
"dojox/widget/nls/az/FilePicker", ({
	"name" : "Ad",
	"size" : "Həcmi (bayt cinsindən)",
	"path" : "Yol"
})
);
