define(
"dojox/widget/nls/pt/FilePicker", ({
	name: "Nome",
	path: "Caminho",
	size: "Tamanho (em bytes)"
})
);
