define(
"dojox/widget/nls/da/Wizard", ({
next: "Næste",
previous: "Forrige",
done: "Udført"
})
);
