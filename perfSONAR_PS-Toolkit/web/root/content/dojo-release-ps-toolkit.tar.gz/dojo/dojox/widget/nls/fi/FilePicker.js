define(
"dojox/widget/nls/fi/FilePicker", ({
	name: "Nimi",
	path: "Polku",
	size: "Koko (tavuina)"
})
);
