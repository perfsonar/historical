define(
"dojox/widget/nls/ru/Wizard", ({
next: "Далее",
previous: "Назад",
done: "Готово"
})
);
