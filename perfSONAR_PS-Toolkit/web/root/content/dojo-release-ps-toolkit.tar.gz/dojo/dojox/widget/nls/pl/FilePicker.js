define(
"dojox/widget/nls/pl/FilePicker", ({
	name: "Nazwa",
	path: "Ścieżka",
	size: "Wielkość (w bajtach)"
})
);
