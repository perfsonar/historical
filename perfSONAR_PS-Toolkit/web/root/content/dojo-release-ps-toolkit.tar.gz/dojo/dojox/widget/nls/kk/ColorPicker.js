define(
"dojox/widget/nls/kk/ColorPicker", ({
redLabel: "r",
greenLabel: "д",
blueLabel: "ә",
hueLabel: "е",
saturationLabel: "ң",
valueLabel: "п", /* aka intensity or brightness */
degLabel: "\u00B0",
hexLabel: "алтылық",
huePickerTitle: "Реңкті іріктеу",
saturationPickerTitle: "Қанықтықты іріктеу"
})
);
