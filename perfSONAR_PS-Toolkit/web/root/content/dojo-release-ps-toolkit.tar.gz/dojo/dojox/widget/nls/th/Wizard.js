define(
"dojox/widget/nls/th/Wizard", ({
next: "ถัดไป",
previous: "ก่อนหน้านี้",
done: "เสร็จแล้ว"
})
);
