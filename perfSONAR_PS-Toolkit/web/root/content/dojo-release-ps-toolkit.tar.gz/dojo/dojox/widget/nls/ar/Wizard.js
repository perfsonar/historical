define(
"dojox/widget/nls/ar/Wizard", ({
next: "تالي",
previous: "‏سابق‏",
done: "اتمام"
})
);
