define(
"dojox/widget/nls/ja/Wizard", ({
next: "次へ",
previous: "前へ",
done: "完了"
})
);
