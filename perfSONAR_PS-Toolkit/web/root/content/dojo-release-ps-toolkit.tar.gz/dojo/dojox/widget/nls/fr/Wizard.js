define(
"dojox/widget/nls/fr/Wizard", ({
next: "Suivant",
previous: "Précédent",
done: "Terminé"
})
);
