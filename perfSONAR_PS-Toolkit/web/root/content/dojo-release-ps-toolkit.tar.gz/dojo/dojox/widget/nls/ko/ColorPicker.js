define(
"dojox/widget/nls/ko/ColorPicker", ({
redLabel: "R",
greenLabel: "G",
blueLabel: "B",
hueLabel: "H",
saturationLabel: "S",
valueLabel: "V", /* aka intensity or brightness */
degLabel: "\u00B0",
hexLabel: "16진",
huePickerTitle: "색상 선택자",
saturationPickerTitle: "채도 선택자"
})
);
