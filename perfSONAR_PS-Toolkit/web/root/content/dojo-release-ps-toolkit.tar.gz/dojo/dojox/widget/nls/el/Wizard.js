define(
"dojox/widget/nls/el/Wizard", ({
next: "Επόμενο",
previous: "Προηγούμενο",
done: "Ολοκλήρωση"
})
);
