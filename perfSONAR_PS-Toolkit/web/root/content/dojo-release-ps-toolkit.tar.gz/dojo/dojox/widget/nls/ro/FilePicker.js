define(
"dojox/widget/nls/ro/FilePicker", ({
	name: "Nume",
	path: "Cale",
	size: "Mărime (în octeţi)"
})
);
