define(
"dojox/widget/nls/ja/FilePicker", ({
	name: "名前",
	path: "パス",
	size: "サイズ (バイト単位)"
})
);
