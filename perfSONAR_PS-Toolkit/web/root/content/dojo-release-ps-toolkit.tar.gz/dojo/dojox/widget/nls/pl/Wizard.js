define(
"dojox/widget/nls/pl/Wizard", ({
next: "Dalej",
previous: "Wstecz",
done: "Gotowe"
})
);
