define(
"dojox/widget/nls/el/FilePicker", ({
	name: "Όνομα",
	path: "Διαδρομή",
	size: "Μέγεθος (σε bytes)"
})
);
