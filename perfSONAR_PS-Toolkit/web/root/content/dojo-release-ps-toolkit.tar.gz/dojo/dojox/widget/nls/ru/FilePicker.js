define(
"dojox/widget/nls/ru/FilePicker", ({
	name: "Имя",
	path: "Путь",
	size: "Размер (байт)"
})
);
