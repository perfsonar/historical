define(
"dojox/widget/nls/ar/FilePicker", ({
	name: "الاسم",
	path: "‏المسار‏",
	size: "الحجم (بالبايت)"
})
);
