define(
"dojox/widget/nls/it/Wizard", ({
next: "Successivo",
previous: "Indietro",
done: "Fine"
})
);
