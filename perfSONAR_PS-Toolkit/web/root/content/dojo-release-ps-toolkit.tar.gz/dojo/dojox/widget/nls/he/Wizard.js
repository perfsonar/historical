define(
"dojox/widget/nls/he/Wizard", ({
next: "הבא",
previous: "הקודם",
done: "סיום"
})
);
