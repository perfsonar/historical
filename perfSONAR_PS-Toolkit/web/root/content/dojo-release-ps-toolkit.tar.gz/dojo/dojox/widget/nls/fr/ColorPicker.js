define(
"dojox/widget/nls/fr/ColorPicker", ({
redLabel: "r",
greenLabel: "v",
blueLabel: "b",
hueLabel: "t",
saturationLabel: "s",
valueLabel: "v", /* aka intensity or brightness */
degLabel: "\u00B0",
hexLabel: "hex",
huePickerTitle: "Sélecteur de teinte",
saturationPickerTitle: "Sélecteur de saturation"
})
);
