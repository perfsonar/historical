define(
"dojox/widget/nls/bg/Wizard", ({
	next: "Следващ",
	previous: "Предишен",
	done: "Готово"
})
);
