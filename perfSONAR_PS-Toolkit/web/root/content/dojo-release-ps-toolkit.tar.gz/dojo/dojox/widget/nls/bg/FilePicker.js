define(
"dojox/widget/nls/bg/FilePicker", ({
	name: "Име",
	path: "Пътека",
	size: "Размер (в байтове)"
})
);
