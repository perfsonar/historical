// wrapped by build app
define("dojox/widget/gauge/AnalogArrowIndicator", ["dijit","dojo","dojox","dojo/require!dojox/gauges/AnalogArrowIndicator"], function(dijit,dojo,dojox){
dojo.provide('dojox.widget.gauge.AnalogArrowIndicator');
dojo.require("dojox.gauges.AnalogArrowIndicator");

dojox.widget.gauge.AnalogArrowIndicator = dojox.gauges.AnalogArrowIndicator;

});
