define(
"dojox/widget/nls/de/FilePicker", ({
	name: "Name",
	path: "Pfad",
	size: "Größe (in Byte)"
})
);
