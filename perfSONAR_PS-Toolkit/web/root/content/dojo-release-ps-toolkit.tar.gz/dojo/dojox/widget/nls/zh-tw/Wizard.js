define(
"dojox/widget/nls/zh-tw/Wizard", ({
next: "下一步",
previous: "上一步",
done: "完成"
})
);
