define(
"dojox/widget/nls/ja/ColorPicker", ({
redLabel: "R",
greenLabel: "G",
blueLabel: "B",
hueLabel: "H",
saturationLabel: "S",
valueLabel: "V", /* aka intensity or brightness */
degLabel: "\u00B0",
hexLabel: "Hex",
huePickerTitle: "色調セレクター",
saturationPickerTitle: "彩度セレクター"
})
);
