define(
"dojox/widget/nls/pt-pt/ColorPicker", ({
redLabel: "e",
greenLabel: "v",
blueLabel: "a",
hueLabel: "t",
valueLabel: "val", /* aka intensity or brightness */
huePickerTitle: "Selector de tonalidade",
saturationPickerTitle: "Selector de saturação"
})
);
