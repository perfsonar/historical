define(
"dojox/widget/nls/uk/Wizard", ({
	next: "Далі",
	previous: "Назад",
	done: "Готово"
})
);
