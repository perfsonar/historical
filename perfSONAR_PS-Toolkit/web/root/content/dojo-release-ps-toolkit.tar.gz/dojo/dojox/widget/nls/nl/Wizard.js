define(
"dojox/widget/nls/nl/Wizard", ({
next: "Volgende",
previous: "Vorige",
done: "Klaar"
})
);
