define(
"dojox/widget/nls/hr/Wizard", ({
next: "Sljedeće",
previous: "Prethodno",
done: "Gotovo"
})
);
