define(
"dojox/widget/nls/nl/ColorPicker", ({
redLabel: "r",
greenLabel: "g",
blueLabel: "b",
hueLabel: "t",
saturationLabel: "i",
valueLabel: "h", /* aka intensity or brightness */
degLabel: "\u00B0",
hexLabel: "hex",
huePickerTitle: "Tint selecteren",
saturationPickerTitle: "Intensiteit selecteren"
})
);
