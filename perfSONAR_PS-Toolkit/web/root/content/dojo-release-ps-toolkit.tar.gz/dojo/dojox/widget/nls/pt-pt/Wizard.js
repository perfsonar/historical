define(
"dojox/widget/nls/pt-pt/Wizard", ({
next: "Seguinte",
previous: "Anterior",
done: "Concluído"
})
);
