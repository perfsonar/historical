define(
"dojox/widget/nls/ar/ColorPicker", ({
huePickerTitle: "محدد تدرج اللون",
saturationPickerTitle: "محدد درجة التشبع"
})
);
