define(
"dojox/widget/nls/tr/Wizard", ({
next: "İleri",
previous: "Geri",
done: "Bitti"
})
);
