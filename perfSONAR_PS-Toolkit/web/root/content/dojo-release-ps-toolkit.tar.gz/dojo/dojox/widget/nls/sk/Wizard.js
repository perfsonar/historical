define(
"dojox/widget/nls/sk/Wizard", ({
next: "Nasledujúci",
previous: "Predchádzajúci",
done: "Hotovo"
})
);
