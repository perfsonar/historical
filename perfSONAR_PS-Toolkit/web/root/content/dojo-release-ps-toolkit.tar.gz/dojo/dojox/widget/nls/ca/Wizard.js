define(
"dojox/widget/nls/ca/Wizard", ({
next: "Següent",
previous: "Anterior",
done: "Fet"
})
);
