define(
"dojox/widget/nls/cs/FilePicker", ({
	name: "Název",
	path: "Cesta",
	size: "Velikost (v bajtech)"
})
);
