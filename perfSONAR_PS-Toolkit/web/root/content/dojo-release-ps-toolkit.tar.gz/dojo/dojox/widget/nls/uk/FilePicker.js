define(
"dojox/widget/nls/uk/FilePicker", ({
	name: "Ім'я",
	path: "Шлях",
	size: "Розмір (у байтах)"
})
);
