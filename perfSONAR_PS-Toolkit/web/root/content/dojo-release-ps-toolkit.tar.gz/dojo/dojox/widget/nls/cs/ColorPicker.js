define(
"dojox/widget/nls/cs/ColorPicker", ({
redLabel: "č",
greenLabel: "z",
blueLabel: "m",
hueLabel: "o",
saturationLabel: "n",
valueLabel: "j", /* aka intensity or brightness */
degLabel: "\u00B0",
hexLabel: "hex",
huePickerTitle: "Selektor odstínu",
saturationPickerTitle: "Selektor sytosti"
})
);
