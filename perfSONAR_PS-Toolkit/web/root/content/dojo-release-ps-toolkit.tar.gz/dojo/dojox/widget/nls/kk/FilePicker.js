define(
"dojox/widget/nls/kk/FilePicker", ({
	name: "Аты",
	path: "Жол",
	size: "Өлшемі (байт)"
})
);
