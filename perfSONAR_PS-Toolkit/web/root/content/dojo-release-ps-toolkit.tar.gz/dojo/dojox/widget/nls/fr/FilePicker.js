define(
"dojox/widget/nls/fr/FilePicker", ({
	name: "Nom",
	path: "Chemin",
	size: "Taille (en octets)"
})
);
