define(
"dojox/widget/nls/de/Wizard", ({
next: "Weiter",
previous: "Zurück",
done: "Fertig"
})
);
