define(
"dojox/widget/nls/nb/FilePicker", ({
	name: "Navn",
	path: "Bane",
	size: "Størrelse (i byte)"
})
);
